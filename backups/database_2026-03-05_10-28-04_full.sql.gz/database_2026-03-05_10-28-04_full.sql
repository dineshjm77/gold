-- Database Backup
-- Generated: 2026-03-05 10:28:04
-- Database: 
-- Tables: activity_log, amount_based_interest, bank_accounts, bank_ledger, bank_loan_emi, bank_loan_items, bank_loan_payments, bank_loans, bank_master, bank_payment_details, bank_stocks, branches, categories, company_expenses, company_settings, customers, defect_details, departments, dynamic_interest, email_logs, email_settings, employee_documents, expense_details, expense_types, fixed_interest, gods_name, interest_settings, investment_returns, investment_types, investments, investors, invoice, karat_details, loan_items, loans, overdue_payments, payment_method_settings, payment_types, payments, product_names, product_types, product_value_settings, stock_dividends, stock_transactions, stone_details, upi_apps, upi_ids, upi_transactions, user_permissions, users

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
START TRANSACTION;

-- Structure for table `activity_log`
DROP TABLE IF EXISTS `activity_log`;
CREATE TABLE `activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `action` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `table_name` varchar(50) DEFAULT NULL,
  `record_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `activity_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=179 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `activity_log`
INSERT INTO `activity_log` (`id`, `user_id`, `action`, `description`, `table_name`, `record_id`, `created_at`) VALUES 
('1', '1', 'logout', 'User logged out', NULL, NULL, '2026-02-23 08:14:52'),
('2', '1', 'login', 'User logged in', 'users', NULL, '2026-02-23 08:56:09'),
('3', '1', 'create', 'New branch created: DHARMAPURI', 'branches', '1', '2026-02-23 10:21:12'),
('4', '1', 'create', 'New employee created', 'users', '5', '2026-02-23 10:38:37'),
('5', '1', 'create', 'New employee created', 'users', '6', '2026-02-23 10:58:20'),
('6', '1', 'create', 'New employee created', 'users', '7', '2026-02-23 11:25:16'),
('7', '1', 'create', 'New employee created', 'users', '8', '2026-02-23 11:36:11'),
('8', '1', 'activated', 'Employee activated', 'users', '8', '2026-02-23 11:45:00'),
('9', '1', 'deactivated', 'Employee deactivated', 'users', '8', '2026-02-23 11:45:10'),
('10', '1', 'activated', 'Employee activated', 'users', '8', '2026-02-23 11:45:14'),
('11', '1', 'delete', 'Employee deleted', 'users', '6', '2026-02-23 11:49:17'),
('12', '1', 'create', 'New customer created', 'customers', '1', '2026-02-23 11:51:21'),
('13', '1', 'login', 'User logged in', 'users', NULL, '2026-02-23 13:37:16'),
('14', '1', 'login', 'User logged in', 'users', NULL, '2026-02-23 17:25:55'),
('15', '1', 'login', 'User logged in', 'users', NULL, '2026-02-23 18:19:39'),
('16', '1', 'create', 'Added new interest type', 'interest_settings', '34', '2026-02-23 18:28:42'),
('17', '1', 'create', 'Added new interest type', 'interest_settings', '35', '2026-02-23 18:35:55'),
('18', '1', 'create', 'Added new interest type', 'interest_settings', '36', '2026-02-23 18:36:00'),
('19', '1', 'create', 'Added new interest type', 'interest_settings', '37', '2026-02-23 18:36:11'),
('20', '1', 'create', 'Added new interest type', 'interest_settings', '38', '2026-02-23 18:42:32'),
('21', '1', 'delete', 'Deleted interest type', 'interest_settings', '29', '2026-02-23 18:42:44'),
('22', '1', 'delete', 'Deleted interest type', 'interest_settings', '32', '2026-02-23 18:42:47'),
('23', '1', 'delete', 'Deleted interest type', 'interest_settings', '33', '2026-02-23 18:42:50'),
('24', '1', 'delete', 'Deleted interest type', 'interest_settings', '34', '2026-02-23 18:42:53'),
('25', '1', 'delete', 'Deleted interest type', 'interest_settings', '35', '2026-02-23 18:42:55'),
('26', '1', 'delete', 'Deleted interest type', 'interest_settings', '36', '2026-02-23 18:42:58'),
('27', '1', 'delete', 'Deleted interest type', 'interest_settings', '37', '2026-02-23 18:43:01'),
('28', '1', 'create', 'Added new interest type', 'interest_settings', '39', '2026-02-23 18:43:25'),
('29', '1', 'login', 'User logged in', 'users', NULL, '2026-02-24 04:59:52'),
('30', '1', 'delete', 'Deleted stone detail', 'stone_details', '1', '2026-02-24 06:01:55'),
('31', '1', 'delete', 'Deleted stone detail', 'stone_details', '2', '2026-02-24 06:01:58'),
('32', '1', 'delete', 'Deleted stone detail', 'stone_details', '8', '2026-02-24 06:02:02'),
('33', '1', 'delete', 'Deleted stone detail', 'stone_details', '3', '2026-02-24 06:02:07'),
('34', '1', 'delete', 'Deleted stone detail', 'stone_details', '4', '2026-02-24 06:05:25'),
('35', '1', 'delete', 'Deleted stone detail', 'stone_details', '5', '2026-02-24 06:05:28'),
('36', '1', 'delete', 'Deleted stone detail', 'stone_details', '6', '2026-02-24 06:05:31'),
('37', '1', 'create', 'Added new stone detail', 'stone_details', '9', '2026-02-24 06:05:39'),
('38', '1', 'delete', 'Deleted defect detail', 'defect_details', '1', '2026-02-24 06:15:00'),
('39', '1', 'delete', 'Deleted defect detail', 'defect_details', '8', '2026-02-24 06:15:03'),
('40', '1', 'delete', 'Deleted defect detail', 'defect_details', '7', '2026-02-24 06:15:05'),
('41', '1', 'delete', 'Deleted defect detail', 'defect_details', '6', '2026-02-24 06:15:08'),
('42', '1', 'delete', 'Deleted defect detail', 'defect_details', '5', '2026-02-24 06:15:10'),
('43', '1', 'delete', 'Deleted defect detail', 'defect_details', '4', '2026-02-24 06:15:12'),
('44', '1', 'delete', 'Deleted defect detail', 'defect_details', '3', '2026-02-24 06:15:14'),
('45', '1', 'login', 'User logged in', 'users', NULL, '2026-02-24 07:24:09'),
('46', '1', 'delete', 'Deleted karat detail', 'karat_details', '8', '2026-02-24 07:27:38'),
('47', '1', 'delete', 'Deleted karat detail', 'karat_details', '7', '2026-02-24 07:27:42'),
('48', '1', 'delete', 'Deleted karat detail', 'karat_details', '1', '2026-02-24 07:27:47'),
('49', '1', 'delete', 'Deleted karat detail', 'karat_details', '2', '2026-02-24 07:27:52'),
('50', '1', 'delete', 'Deleted karat detail', 'karat_details', '3', '2026-02-24 07:27:55'),
('51', '1', 'delete', 'Deleted karat detail', 'karat_details', '4', '2026-02-24 07:28:01'),
('52', '1', 'create', 'Added new product name', 'product_names', '10', '2026-02-24 07:32:38'),
('53', '1', 'delete', 'Deleted product name', 'product_names', '1', '2026-02-24 07:32:45'),
('54', '1', 'delete', 'Deleted product name', 'product_names', '2', '2026-02-24 07:32:50'),
('55', '1', 'delete', 'Deleted product name', 'product_names', '3', '2026-02-24 07:32:54'),
('56', '1', 'delete', 'Deleted product name', 'product_names', '4', '2026-02-24 07:32:56'),
('57', '1', 'delete', 'Deleted product name', 'product_names', '5', '2026-02-24 07:32:58'),
('58', '1', 'delete', 'Deleted product name', 'product_names', '6', '2026-02-24 07:33:00'),
('59', '1', 'delete', 'Deleted product name', 'product_names', '7', '2026-02-24 07:33:02'),
('60', '1', 'create', 'Added new product type', 'product_types', '3', '2026-02-24 07:39:05'),
('61', '1', 'create', 'Added new investor', 'investors', '2', '2026-02-24 08:14:38'),
('62', '1', 'delete', 'Deleted investment', 'investments', '1', '2026-02-24 09:48:15'),
('63', '1', 'delete', 'Deleted investment', 'investments', '2', '2026-02-24 09:48:24'),
('64', '1', 'create', 'Added new investment', 'investments', '3', '2026-02-24 10:00:34'),
('65', '1', 'login', 'User logged in', 'users', NULL, '2026-02-24 16:42:05'),
('66', '1', 'login', 'User logged in', 'users', NULL, '2026-02-25 04:27:40'),
('67', '1', 'create', 'Added new interest type', 'interest_settings', '40', '2026-02-25 05:55:40'),
('68', '1', 'create', 'Added new fixed interest', 'fixed_interest', '8', '2026-02-25 06:23:19'),
('69', '1', 'delete', 'Deleted fixed interest', 'fixed_interest', '1', '2026-02-25 06:23:28'),
('70', '1', 'delete', 'Deleted fixed interest', 'fixed_interest', '2', '2026-02-25 06:23:32'),
('71', '1', 'delete', 'Deleted fixed interest', 'fixed_interest', '3', '2026-02-25 06:23:35'),
('72', '1', 'delete', 'Deleted fixed interest', 'fixed_interest', '4', '2026-02-25 06:23:38'),
('73', '1', 'delete', 'Deleted fixed interest', 'fixed_interest', '5', '2026-02-25 06:23:41'),
('74', '1', 'delete', 'Deleted fixed interest', 'fixed_interest', '6', '2026-02-25 06:23:45'),
('75', '1', 'delete', 'Deleted fixed interest', 'fixed_interest', '7', '2026-02-25 06:23:47'),
('76', '1', 'create', 'Added new fixed interest', 'fixed_interest', '9', '2026-02-25 06:24:12'),
('77', '1', 'create', 'Added new dynamic interest', 'dynamic_interest', '5', '2026-02-25 06:57:20'),
('78', '1', 'delete', 'Deleted dynamic interest', 'dynamic_interest', '5', '2026-02-25 06:57:39'),
('79', '1', 'delete', 'Deleted dynamic interest', 'dynamic_interest', '1', '2026-02-25 06:57:44'),
('80', '1', 'delete', 'Deleted dynamic interest', 'dynamic_interest', '2', '2026-02-25 06:57:49'),
('81', '1', 'delete', 'Deleted dynamic interest', 'dynamic_interest', '3', '2026-02-25 06:57:52'),
('82', '1', 'delete', 'Deleted dynamic interest', 'dynamic_interest', '4', '2026-02-25 06:57:56'),
('83', '1', 'create', 'Added new dynamic interest', 'dynamic_interest', '6', '2026-02-25 06:58:44'),
('84', '1', 'update', 'Updated dynamic interest', 'dynamic_interest', '6', '2026-02-25 06:59:07'),
('85', '1', 'update', 'Updated dynamic interest', 'dynamic_interest', '6', '2026-02-25 06:59:27'),
('86', '1', 'delete', 'Deleted amount based interest', 'amount_based_interest', '2', '2026-02-25 07:07:59'),
('87', '1', 'delete', 'Deleted amount based interest', 'amount_based_interest', '1', '2026-02-25 07:08:04'),
('88', '1', 'create', 'Added new amount based interest', 'amount_based_interest', '3', '2026-02-25 07:08:35'),
('89', '1', 'update', 'Updated amount based interest', 'amount_based_interest', '3', '2026-02-25 07:08:45'),
('90', '1', 'create', 'Added new expense detail', 'expense_details', '4', '2026-02-25 08:02:58'),
('91', '1', 'create', 'Added new expense detail', 'expense_details', '5', '2026-02-25 11:09:39'),
('92', '1', 'create', 'Added new expense detail', 'expense_details', '6', '2026-02-25 11:10:04'),
('93', '1', 'logout', 'User logged out', NULL, NULL, '2026-02-25 11:43:25'),
('94', '1', 'login', 'User logged in', 'users', NULL, '2026-02-25 11:43:28'),
('95', '1', 'logout', 'User logged out', NULL, NULL, '2026-02-25 11:44:33'),
('96', '9', 'login', 'User logged in', 'users', NULL, '2026-02-25 11:47:11'),
('97', '9', 'logout', 'User logged out', NULL, NULL, '2026-02-25 11:47:52'),
('98', '1', 'login', 'User logged in', 'users', NULL, '2026-02-25 11:47:55'),
('99', '1', 'logout', 'User logged out', NULL, NULL, '2026-02-25 11:55:00'),
('100', '1', 'login', 'User logged in', 'users', NULL, '2026-02-25 11:55:31');
INSERT INTO `activity_log` (`id`, `user_id`, `action`, `description`, `table_name`, `record_id`, `created_at`) VALUES 
('101', '1', 'logout', 'User logged out', NULL, NULL, '2026-02-25 11:55:38'),
('102', '1', 'login', 'User logged in', 'users', NULL, '2026-02-25 11:55:48'),
('103', '1', 'create', 'Added new bank: sbi', 'bank_master', '4', '2026-02-25 15:07:36'),
('104', '1', 'create', 'Added new bank account: 12', 'bank_accounts', '2', '2026-02-25 15:38:32'),
('105', '1', 'create', 'New loan created: 260225001', 'loans', '1', '2026-02-25 16:13:58'),
('106', '1', 'login', 'User logged in', 'users', NULL, '2026-02-25 16:35:48'),
('107', '1', 'login', 'User logged in', 'users', NULL, '2026-02-25 16:57:40'),
('108', '1', 'login', 'User logged in', 'users', NULL, '2026-02-25 17:04:30'),
('109', '1', 'login', 'User logged in', 'users', NULL, '2026-02-25 17:44:11'),
('110', '1', 'login', 'User logged in', 'users', NULL, '2026-02-26 03:19:53'),
('111', '1', 'login', 'User logged in', 'users', NULL, '2026-02-26 05:34:13'),
('112', '1', 'create', 'New customer created: wqwe', 'customers', '3', '2026-02-26 07:21:25'),
('113', '1', 'create', 'New loan created: 260226001', 'loans', '2', '2026-02-26 07:33:16'),
('114', '1', 'create', 'New loan created: 260226002', 'loans', '3', '2026-02-26 09:10:09'),
('115', '1', 'close', 'Loan closed with final payment of ₹100,400.00', 'loans', '1', '2026-02-26 10:35:05'),
('116', '1', 'bulk_close', 'Bulk closed 1 loans for customer ID 0, total amount: ₹10,510.00', 'loans', '0', '2026-02-26 12:53:42'),
('117', '1', 'login', 'User logged in', 'users', NULL, '2026-02-26 16:25:09'),
('118', '1', 'logout', 'User logged out', NULL, NULL, '2026-02-26 16:40:40'),
('119', '1', 'login', 'User logged in', 'users', NULL, '2026-02-26 16:40:42'),
('120', '1', 'create', 'New branch created: welth', 'branches', '2', '2026-02-26 16:56:51'),
('121', '1', 'create', 'New loan created: 260226003', 'loans', '4', '2026-02-26 17:13:22'),
('122', '1', 'update', 'Loan updated: 260226003', 'loans', '4', '2026-02-26 20:04:16'),
('123', '1', 'update', 'Loan updated: 260226003', 'loans', '4', '2026-02-26 20:13:32'),
('124', '1', 'login', 'User logged in', 'users', NULL, '2026-02-27 07:46:35'),
('125', '1', 'create', 'Added product value setting: தங்கம்', 'product_value_settings', NULL, '2026-02-27 08:17:13'),
('126', '1', 'create', 'New customer created: munisamy', 'customers', '4', '2026-02-27 10:20:32'),
('127', '1', 'create', 'New loan created: 260227001', 'loans', '5', '2026-02-27 10:48:43'),
('128', '1', 'login', 'User logged in', 'users', NULL, '2026-02-27 15:11:14'),
('129', '1', 'login', 'User logged in', 'users', NULL, '2026-02-27 15:23:36'),
('130', '1', 'login', 'User logged in', 'users', NULL, '2026-02-27 15:23:53'),
('131', '1', 'create', 'New customer created: Rajasekarlingam Periyasami', 'customers', '5', '2026-02-27 15:27:57'),
('132', '1', 'update', 'Updated product value setting: தங்கம்', 'product_value_settings', NULL, '2026-02-27 15:31:57'),
('133', '1', 'create', 'New loan created: 260227002', 'loans', '6', '2026-02-27 15:41:34'),
('134', '1', 'interest_collection', 'Interest of ₹66.67 collected by Administrator for Loan #260226003', 'payments', '4', '2026-02-27 15:57:44'),
('135', '1', 'interest_collection', 'Interest of ₹66.67 collected by Administrator for Loan #260226003', 'payments', '4', '2026-02-27 15:59:02'),
('136', '1', 'close', 'Loan closed with final payment of ₹126,200.00', 'loans', '5', '2026-02-27 16:03:28'),
('137', '1', 'login', 'User logged in', 'users', NULL, '2026-02-27 16:19:11'),
('138', '1', 'create', 'New customer created: wrqw', 'customers', '6', '2026-02-27 16:42:21'),
('139', '1', 'create', 'New customer created: WQWQ', 'customers', '7', '2026-02-27 17:13:23'),
('140', '1', 'create', 'New customer created: saas', 'customers', '8', '2026-02-27 17:30:39'),
('141', '1', 'principal_payment', 'Principal of ₹23,500.00 paid by Administrator for Loan #260227002', 'payments', '6', '2026-02-27 19:32:18'),
('142', '1', 'update', 'Branch updated: DHARMAPURI', 'branches', '1', '2026-02-27 20:17:53'),
('143', '1', 'login', 'User logged in', 'users', NULL, '2026-03-02 15:37:11'),
('144', '1', 'login', 'User logged in', 'users', NULL, '2026-03-02 16:25:26'),
('145', '1', 'create', 'New loan created: 260302001', 'loans', '7', '2026-03-02 17:39:31'),
('146', '1', 'create', 'New loan created: 260302002', 'loans', '8', '2026-03-02 17:41:41'),
('147', '1', 'create', 'New loan created: 260302003', 'loans', '9', '2026-03-02 17:46:14'),
('148', '1', 'login', 'User logged in', 'users', NULL, '2026-03-02 18:07:12'),
('149', '1', 'create', 'New loan created: 260302004', 'loans', '10', '2026-03-02 18:08:21'),
('150', '1', 'create', 'New loan created: 260302005', 'loans', '11', '2026-03-02 18:14:08'),
('151', '1', 'create', 'New loan created: 260302006', 'loans', '12', '2026-03-02 18:16:39'),
('152', '1', 'create', 'New loan created: 260302007', 'loans', '13', '2026-03-02 18:41:32'),
('153', '1', 'create', 'New loan created: 260302008', 'loans', '14', '2026-03-02 18:43:22'),
('154', '1', 'create', 'Added new expense detail', 'expense_details', '1', '2026-03-02 19:10:17'),
('155', '1', 'create', 'Added new expense detail', 'expense_details', '1', '2026-03-02 19:11:25'),
('156', '1', 'login', 'User logged in', 'users', NULL, '2026-03-02 19:20:37'),
('157', '1', 'login', 'User logged in', 'users', NULL, '2026-03-02 19:31:48'),
('158', '1', 'create', 'Added new expense detail', 'expense_details', '3', '2026-03-02 21:42:39'),
('159', '1', 'create', 'Added new expense detail', 'expense_details', '4', '2026-03-02 21:44:38'),
('160', '1', 'create', 'Added new expense detail', 'expense_details', '5', '2026-03-02 21:45:37'),
('161', '1', 'create', 'Added new expense detail', 'expense_details', '6', '2026-03-02 21:45:57'),
('162', '1', 'login', 'User logged in', 'users', NULL, '2026-03-03 06:08:30'),
('163', '1', 'bulk_close', 'Bulk closed 3 loans for customer ID 0, total amount: ₹391,125.00', 'loans', '0', '2026-03-03 06:20:57'),
('164', '1', 'interest_collection', 'Interest of ₹59.60 collected by Administrator for Loan #260302001', 'payments', '7', '2026-03-03 06:26:06'),
('165', '1', 'create', 'Added new expense detail', 'expense_details', '7', '2026-03-03 06:59:16'),
('166', '1', 'login', 'User logged in', 'users', NULL, '2026-03-03 07:19:36'),
('167', '1', 'login', 'User logged in', 'users', NULL, '2026-03-03 09:03:59'),
('168', '1', 'create', 'Added new expense detail', 'expense_details', '8', '2026-03-03 09:06:17'),
('169', '1', 'interest_collection', 'Interest of ₹59.60 + Charge ₹10.00 collected by Administrator for Loan #260302002', 'payments', '8', '2026-03-03 09:59:08'),
('170', '1', 'interest_collection', 'Payment of ₹79.60 (Interest: ₹59.60 + Charge: ₹20.00) collected by Administrator for Loan #260302004', 'payments', '10', '2026-03-03 10:41:34'),
('171', '1', 'login', 'User logged in', 'users', NULL, '2026-03-05 05:26:26'),
('172', '1', 'login', 'User logged in', 'users', NULL, '2026-03-05 05:36:15'),
('173', '1', 'create', 'Created bank loan: BNK-L20260305-0001 for ₹10,000.00', 'bank_loans', '1', '2026-03-05 05:51:59'),
('174', '1', 'create', 'Added new interest type', 'interest_settings', '41', '2026-03-05 08:09:16'),
('175', '1', 'update', 'Updated interest type', 'interest_settings', '41', '2026-03-05 08:09:38'),
('176', '1', 'create', 'Added new fixed interest', 'fixed_interest', '10', '2026-03-05 08:10:31'),
('177', '1', 'update', 'Updated stone detail', 'stone_details', '7', '2026-03-05 09:48:51'),
('178', '1', 'update', 'Updated stone detail', 'stone_details', '9', '2026-03-05 09:49:00');

-- Structure for table `amount_based_interest`
DROP TABLE IF EXISTS `amount_based_interest`;
CREATE TABLE `amount_based_interest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_type` varchar(100) NOT NULL,
  `interest_type` varchar(150) NOT NULL,
  `from_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `to_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `upto_1_year` decimal(5,2) NOT NULL DEFAULT 0.00,
  `above_1_year` decimal(5,2) NOT NULL DEFAULT 0.00,
  `above_2_years` decimal(5,2) NOT NULL DEFAULT 0.00,
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `amount_based_interest`
INSERT INTO `amount_based_interest` (`id`, `product_type`, `interest_type`, `from_amount`, `to_amount`, `upto_1_year`, `above_1_year`, `above_2_years`, `status`, `created_at`, `updated_at`) VALUES 
('3', 'தங்கம்', '2', '1.00', '1.00', '2.00', '1.00', '1.00', '1', '2026-02-25 07:08:35', '2026-02-25 07:08:45');

-- Structure for table `bank_accounts`
DROP TABLE IF EXISTS `bank_accounts`;
CREATE TABLE `bank_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_holder_no` varchar(100) NOT NULL,
  `bank_account_no` varchar(50) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `branch` varchar(150) NOT NULL,
  `ifsc_code` varchar(20) NOT NULL,
  `account_type` varchar(50) NOT NULL,
  `authorized_person` varchar(150) NOT NULL,
  `registered_mobile` varchar(15) NOT NULL,
  `opening_balance` decimal(15,2) NOT NULL DEFAULT 0.00,
  `as_on_date` date NOT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `bank_id` (`bank_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `bank_accounts`
INSERT INTO `bank_accounts` (`id`, `account_holder_no`, `bank_account_no`, `bank_id`, `branch`, `ifsc_code`, `account_type`, `authorized_person`, `registered_mobile`, `opening_balance`, `as_on_date`, `status`, `created_at`, `updated_at`) VALUES 
('1', 'SRI VINAYAGA', '112255', '1', 'CBE', 'SBIN0012345', 'Savings', 'SRI VINAYAGA', '7373888777', '10000.00', '2025-12-18', '1', '2026-02-25 15:14:43', '2026-02-25 15:14:43'),
('2', '12', '45454545454', '4', 'dharmapuri', 'sbin00067', 'Current', 'sfdsfewr', '5454521215', '1000.00', '2026-02-25', '1', '2026-02-25 15:38:32', '2026-02-25 15:38:41');

-- Structure for table `bank_ledger`
DROP TABLE IF EXISTS `bank_ledger`;
CREATE TABLE `bank_ledger` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entry_date` date NOT NULL,
  `bank_id` int(11) NOT NULL,
  `bank_account_id` int(11) DEFAULT NULL,
  `transaction_type` enum('credit','debit','transfer') NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `balance` decimal(15,2) NOT NULL,
  `reference_number` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `payment_id` int(11) DEFAULT NULL,
  `loan_id` int(11) DEFAULT NULL,
  `investment_id` int(11) DEFAULT NULL,
  `expense_id` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `bank_id` (`bank_id`),
  KEY `bank_account_id` (`bank_account_id`),
  KEY `entry_date` (`entry_date`),
  KEY `transaction_type` (`transaction_type`),
  KEY `reference_number` (`reference_number`),
  KEY `payment_id` (`payment_id`),
  KEY `loan_id` (`loan_id`),
  KEY `created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Structure for table `bank_loan_emi`
DROP TABLE IF EXISTS `bank_loan_emi`;
CREATE TABLE `bank_loan_emi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_loan_id` int(11) NOT NULL,
  `installment_no` int(11) NOT NULL,
  `due_date` date NOT NULL,
  `principal_amount` decimal(15,2) NOT NULL,
  `interest_amount` decimal(15,2) NOT NULL,
  `emi_amount` decimal(15,2) NOT NULL,
  `balance_amount` decimal(15,2) NOT NULL,
  `status` enum('pending','paid','overdue') DEFAULT 'pending',
  `paid_date` date DEFAULT NULL,
  `paid_amount` decimal(15,2) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `bank_loan_id` (`bank_loan_id`),
  KEY `due_date` (`due_date`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `bank_loan_emi`
INSERT INTO `bank_loan_emi` (`id`, `bank_loan_id`, `installment_no`, `due_date`, `principal_amount`, `interest_amount`, `emi_amount`, `balance_amount`, `status`, `paid_date`, `paid_amount`, `payment_method`, `remarks`, `created_at`, `updated_at`) VALUES 
('1', '1', '1', '2026-04-05', '827.62', '12.50', '840.12', '9172.38', 'pending', NULL, NULL, NULL, NULL, '2026-03-05 05:51:59', '2026-03-05 05:51:59'),
('2', '1', '2', '2026-05-05', '828.65', '11.47', '840.12', '8343.73', 'pending', NULL, NULL, NULL, NULL, '2026-03-05 05:51:59', '2026-03-05 05:51:59'),
('3', '1', '3', '2026-06-05', '829.69', '10.43', '840.12', '7514.04', 'pending', NULL, NULL, NULL, NULL, '2026-03-05 05:51:59', '2026-03-05 05:51:59'),
('4', '1', '4', '2026-07-05', '830.73', '9.39', '840.12', '6683.31', 'pending', NULL, NULL, NULL, NULL, '2026-03-05 05:51:59', '2026-03-05 05:51:59'),
('5', '1', '5', '2026-08-05', '831.77', '8.35', '840.12', '5851.54', 'pending', NULL, NULL, NULL, NULL, '2026-03-05 05:51:59', '2026-03-05 05:51:59'),
('6', '1', '6', '2026-09-05', '832.81', '7.31', '840.12', '5018.74', 'pending', NULL, NULL, NULL, NULL, '2026-03-05 05:51:59', '2026-03-05 05:51:59'),
('7', '1', '7', '2026-10-05', '833.85', '6.27', '840.12', '4184.89', 'pending', NULL, NULL, NULL, NULL, '2026-03-05 05:51:59', '2026-03-05 05:51:59'),
('8', '1', '8', '2026-11-05', '834.89', '5.23', '840.12', '3350.00', 'pending', NULL, NULL, NULL, NULL, '2026-03-05 05:51:59', '2026-03-05 05:51:59'),
('9', '1', '9', '2026-12-05', '835.93', '4.19', '840.12', '2514.07', 'pending', NULL, NULL, NULL, NULL, '2026-03-05 05:51:59', '2026-03-05 05:51:59'),
('10', '1', '10', '2027-01-05', '836.98', '3.14', '840.12', '1677.09', 'pending', NULL, NULL, NULL, NULL, '2026-03-05 05:51:59', '2026-03-05 05:51:59'),
('11', '1', '11', '2027-02-05', '838.02', '2.10', '840.12', '839.07', 'pending', NULL, NULL, NULL, NULL, '2026-03-05 05:51:59', '2026-03-05 05:51:59'),
('12', '1', '12', '2027-03-05', '839.07', '1.05', '840.12', '0.00', 'pending', NULL, NULL, NULL, NULL, '2026-03-05 05:51:59', '2026-03-05 05:51:59');

-- Structure for table `bank_loan_items`
DROP TABLE IF EXISTS `bank_loan_items`;
CREATE TABLE `bank_loan_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_loan_id` int(11) NOT NULL,
  `jewel_name` varchar(150) NOT NULL,
  `karat` decimal(4,2) NOT NULL,
  `defect_details` text DEFAULT NULL,
  `stone_details` text DEFAULT NULL,
  `net_weight` decimal(10,3) NOT NULL,
  `quantity` int(11) DEFAULT 1,
  `photo_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `bank_loan_id` (`bank_loan_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `bank_loan_items`
INSERT INTO `bank_loan_items` (`id`, `bank_loan_id`, `jewel_name`, `karat`, `defect_details`, `stone_details`, `net_weight`, `quantity`, `photo_path`, `created_at`) VALUES 
('1', '1', 'வேழ்ஸ் மொதிரம்', '0.00', '', '', '16.000', '1', NULL, '2026-03-05 05:51:59');

-- Structure for table `bank_loan_payments`
DROP TABLE IF EXISTS `bank_loan_payments`;
CREATE TABLE `bank_loan_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_loan_id` int(11) NOT NULL,
  `emi_id` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_amount` decimal(15,2) NOT NULL,
  `payment_method` varchar(50) DEFAULT 'cash',
  `receipt_number` varchar(50) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `receipt_number` (`receipt_number`),
  KEY `bank_loan_id` (`bank_loan_id`),
  KEY `emi_id` (`emi_id`),
  KEY `employee_id` (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Structure for table `bank_loans`
DROP TABLE IF EXISTS `bank_loans`;
CREATE TABLE `bank_loans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loan_reference` varchar(50) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `bank_account_id` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `loan_date` date NOT NULL,
  `loan_amount` decimal(15,2) NOT NULL,
  `interest_rate` decimal(5,2) NOT NULL,
  `tenure_months` int(11) NOT NULL,
  `emi_amount` decimal(15,2) NOT NULL,
  `total_interest` decimal(15,2) NOT NULL,
  `document_charge` decimal(10,2) DEFAULT 0.00,
  `processing_fee` decimal(10,2) DEFAULT 0.00,
  `total_payable` decimal(15,2) NOT NULL,
  `product_type` varchar(100) DEFAULT NULL,
  `item_description` text NOT NULL,
  `item_value` decimal(15,2) DEFAULT NULL,
  `employee_id` int(11) NOT NULL,
  `remarks` text DEFAULT NULL,
  `status` enum('active','closed','defaulted') DEFAULT 'active',
  `close_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `loan_reference` (`loan_reference`),
  KEY `bank_id` (`bank_id`),
  KEY `customer_id` (`customer_id`),
  KEY `employee_id` (`employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `bank_loans`
INSERT INTO `bank_loans` (`id`, `loan_reference`, `bank_id`, `bank_account_id`, `customer_id`, `loan_date`, `loan_amount`, `interest_rate`, `tenure_months`, `emi_amount`, `total_interest`, `document_charge`, `processing_fee`, `total_payable`, `product_type`, `item_description`, `item_value`, `employee_id`, `remarks`, `status`, `close_date`, `created_at`, `updated_at`) VALUES 
('1', 'BNK-L20260305-0001', '4', '2', '5', '2026-03-05', '10000.00', '1.00', '12', '840.12', '81.44', '0.00', '0.00', '10081.44', 'தங்கம்', '', NULL, '1', '', 'active', NULL, '2026-03-05 05:51:59', '2026-03-05 05:51:59');

-- Structure for table `bank_master`
DROP TABLE IF EXISTS `bank_master`;
CREATE TABLE `bank_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_full_name` varchar(200) NOT NULL,
  `bank_short_name` varchar(50) NOT NULL,
  `branch_location` varchar(150) NOT NULL,
  `ifsc_code` varchar(20) NOT NULL,
  `branch_phone` varchar(15) NOT NULL,
  `branch_manager_phone` varchar(15) NOT NULL,
  `address` text DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `bank_master`
INSERT INTO `bank_master` (`id`, `bank_full_name`, `bank_short_name`, `branch_location`, `ifsc_code`, `branch_phone`, `branch_manager_phone`, `address`, `status`, `created_at`, `updated_at`) VALUES 
('1', 'State Bank of India', 'SBI', 'CBE', '12345678900', '0000000000', '0000000000', 'Main Branch, Coimbatore', '1', '2026-02-25 15:01:05', '2026-02-25 15:01:05'),
('2', 'Indian Bank', 'IB', 'CHENNAI', 'KVBL0001119', '1', '1234567890', 'Anna Salai, Chennai', '1', '2026-02-25 15:01:05', '2026-02-25 15:01:05'),
('3', 'Tamilnad mercantile Bank', 'TMB', 'Avalchinampalayam', '55555666555', '55555555555', '55555555555', 'Avalchinampalayam Branch', '1', '2026-02-25 15:01:05', '2026-02-25 15:01:05'),
('4', 'sbi', 'sbi', 'dharmapuri', 'sbin00067', '7658585252', '8585858585', 'dpi', '1', '2026-02-25 15:07:36', '2026-02-25 15:36:48');

-- Structure for table `bank_payment_details`
DROP TABLE IF EXISTS `bank_payment_details`;
CREATE TABLE `bank_payment_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_type_id` int(11) NOT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `bank_account_id` int(11) DEFAULT NULL,
  `upi_id` varchar(100) DEFAULT NULL,
  `qr_code_path` varchar(255) DEFAULT NULL,
  `account_holder` varchar(150) DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `payment_type_id` (`payment_type_id`),
  KEY `bank_id` (`bank_id`),
  KEY `bank_account_id` (`bank_account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Structure for table `bank_stocks`
DROP TABLE IF EXISTS `bank_stocks`;
CREATE TABLE `bank_stocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_code` varchar(50) NOT NULL,
  `stock_name` varchar(200) NOT NULL,
  `stock_type` enum('share','bond','mutual_fund','fixed_deposit','gold','silver','other') DEFAULT 'other',
  `bank_id` int(11) DEFAULT NULL,
  `purchase_date` date NOT NULL,
  `purchase_price` decimal(15,2) NOT NULL,
  `current_price` decimal(15,2) DEFAULT NULL,
  `quantity` decimal(15,3) NOT NULL DEFAULT 1.000,
  `total_investment` decimal(15,2) NOT NULL,
  `current_value` decimal(15,2) DEFAULT NULL,
  `profit_loss` decimal(15,2) DEFAULT NULL,
  `profit_loss_percentage` decimal(10,2) DEFAULT NULL,
  `isin_code` varchar(50) DEFAULT NULL,
  `symbol` varchar(50) DEFAULT NULL,
  `maturity_date` date DEFAULT NULL,
  `interest_rate` decimal(10,2) DEFAULT NULL,
  `dividend_yield` decimal(10,2) DEFAULT NULL,
  `broker_name` varchar(200) DEFAULT NULL,
  `brokerage` decimal(10,2) DEFAULT NULL,
  `certificate_number` varchar(100) DEFAULT NULL,
  `holder_name` varchar(200) NOT NULL,
  `nominee_name` varchar(200) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `document_path` varchar(255) DEFAULT NULL,
  `status` enum('active','sold','matured','closed') DEFAULT 'active',
  `sold_date` date DEFAULT NULL,
  `sold_price` decimal(15,2) DEFAULT NULL,
  `sold_value` decimal(15,2) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `stock_code` (`stock_code`),
  KEY `bank_id` (`bank_id`),
  KEY `stock_type` (`stock_type`),
  KEY `status` (`status`),
  KEY `purchase_date` (`purchase_date`),
  KEY `maturity_date` (`maturity_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Structure for table `branches`
DROP TABLE IF EXISTS `branches`;
CREATE TABLE `branches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_name` varchar(100) NOT NULL,
  `branch_code` varchar(10) NOT NULL,
  `address` text DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `manager_name` varchar(100) DEFAULT NULL,
  `manager_mobile` varchar(15) DEFAULT NULL,
  `manager_id` int(11) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `opening_time` time DEFAULT NULL,
  `closing_time` time DEFAULT NULL,
  `holiday` varchar(20) DEFAULT 'Sunday',
  `logo_path` varchar(255) DEFAULT NULL,
  `qr_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `branch_code` (`branch_code`),
  KEY `manager_id` (`manager_id`),
  CONSTRAINT `branches_ibfk_1` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `branches`
INSERT INTO `branches` (`id`, `branch_name`, `branch_code`, `address`, `phone`, `email`, `website`, `manager_name`, `manager_mobile`, `manager_id`, `status`, `opening_time`, `closing_time`, `holiday`, `logo_path`, `qr_path`, `created_at`, `updated_at`) VALUES 
('1', 'DHARMAPURI', 'BR001', 'DPI', '4575848575', '', 'https://www.example.com', 'DJ', '45758485788', NULL, 'active', '09:00:00', '18:00:00', 'Sunday', 'uploads/branches/logo_BR001_1772223473.png', NULL, '2026-02-23 10:21:12', '2026-02-27 20:17:53'),
('2', 'welth', 'BR002', 'thafjefjwepojqeopqwe', '52525285854', 'dines1121@gmail.com', 'https://whitesmoke-leopard-558579.hostingersite.com/pawndpi/add_branch.php', 'dinesh', '7604950293', '1', 'active', '09:00:00', '18:00:00', 'Sunday', 'uploads/branches/logo_BR002_1772125011.png', 'uploads/branches/qr_BR002_1772125011.png', '2026-02-26 16:56:51', '2026-02-26 16:56:51');

-- Structure for table `categories`
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) NOT NULL,
  `purchase_price` decimal(12,2) DEFAULT 0.00,
  `gram_value` decimal(10,3) DEFAULT 0.000,
  `min_stock_level` decimal(10,3) DEFAULT 0.000,
  `total_quantity` decimal(10,3) DEFAULT 0.000,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_name` (`category_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Structure for table `company_expenses`
DROP TABLE IF EXISTS `company_expenses`;
CREATE TABLE `company_expenses` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `expense_date` date NOT NULL,
  `category` varchar(60) NOT NULL DEFAULT 'general',
  `method` varchar(30) DEFAULT NULL,
  `reference_no` varchar(80) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ce_company` (`company_id`),
  KEY `idx_ce_date` (`expense_date`),
  KEY `idx_ce_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- Data for table `company_expenses`
INSERT INTO `company_expenses` (`id`, `company_id`, `amount`, `expense_date`, `category`, `method`, `reference_no`, `note`, `created_by`, `created_at`) VALUES 
('1', '4', '50000.00', '2026-01-14', 'สมัครสมัคร', 'cash', 'REC-41', 'Expense: สมัครสมัคร - สมัครสมัคร', '1', '2026-03-02 21:41:47'),
('2', '4', '15000.00', '2025-12-12', 'คะแนนการจัดจ้าง', 'bank', 'REC-39', 'Expense: คะแนนการจัดจ้าง - จุดสมัครปี 2025', '1', '2026-03-02 21:41:47'),
('3', '4', '50000.00', '2026-03-02', 'கடை வாடைக', 'cash', 'REC-42', 'Expense: கடை வாடைக - rent payment', '1', '2026-03-02 21:42:39');

-- Structure for table `company_settings`
DROP TABLE IF EXISTS `company_settings`;
CREATE TABLE `company_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(200) NOT NULL,
  `address` text DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `alternate_phone` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `gst_no` varchar(20) DEFAULT NULL,
  `pan_no` varchar(20) DEFAULT NULL,
  `logo_path` varchar(255) DEFAULT NULL,
  `signature_path` varchar(255) DEFAULT NULL,
  `stamp_path` varchar(255) DEFAULT NULL,
  `qr_code_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Structure for table `customers`
DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(150) NOT NULL,
  `guardian_type` enum('Father','Mother','Husband','Other') DEFAULT NULL,
  `guardian_name` varchar(150) DEFAULT NULL,
  `mobile_number` varchar(15) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `whatsapp_number` varchar(15) DEFAULT NULL,
  `alternate_mobile` varchar(15) DEFAULT NULL,
  `door_no` varchar(50) DEFAULT NULL,
  `house_name` varchar(100) DEFAULT NULL,
  `street_name` varchar(150) NOT NULL,
  `street_name1` varchar(150) DEFAULT NULL,
  `landmark` varchar(150) DEFAULT NULL,
  `location` varchar(150) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `post` varchar(100) NOT NULL,
  `taluk` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `aadhaar_number` varchar(20) DEFAULT NULL,
  `company_name` varchar(150) DEFAULT NULL,
  `referral_person` varchar(150) DEFAULT NULL,
  `referral_mobile` varchar(15) DEFAULT NULL,
  `alert_message` text DEFAULT NULL,
  `loan_limit_amount` decimal(15,2) DEFAULT 10000000.00,
  `is_noted_person` tinyint(1) DEFAULT 0,
  `noted_person_remarks` text DEFAULT NULL,
  `customer_photo` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `account_holder_name` varchar(150) DEFAULT NULL,
  `bank_name` varchar(150) DEFAULT NULL,
  `branch_name` varchar(150) DEFAULT NULL,
  `account_number` varchar(50) DEFAULT NULL,
  `ifsc_code` varchar(20) DEFAULT NULL,
  `account_type` enum('savings','current','salary') DEFAULT 'savings',
  `upi_id` varchar(100) DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `place_id` varchar(255) DEFAULT NULL,
  `formatted_address` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mobile_number` (`mobile_number`),
  KEY `idx_mobile` (`mobile_number`),
  KEY `idx_name` (`customer_name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `customers`
INSERT INTO `customers` (`id`, `customer_name`, `guardian_type`, `guardian_name`, `mobile_number`, `email`, `whatsapp_number`, `alternate_mobile`, `door_no`, `house_name`, `street_name`, `street_name1`, `landmark`, `location`, `pincode`, `post`, `taluk`, `district`, `aadhaar_number`, `company_name`, `referral_person`, `referral_mobile`, `alert_message`, `loan_limit_amount`, `is_noted_person`, `noted_person_remarks`, `customer_photo`, `created_at`, `updated_at`, `account_holder_name`, `bank_name`, `branch_name`, `account_number`, `ifsc_code`, `account_type`, `upi_id`, `latitude`, `longitude`, `place_id`, `formatted_address`) VALUES 
('1', 'mani', 'Father', 'dinesh', '7604950293', 'ariharasudhan1062003@gmail.com', '7604950293', '', '12/15', 'dinesh', 'dpi', '', '', 'dharmpauri', '758485', 'ddr', 'erwer', 'rew', '', '', '', '', '', '10000000.00', '0', NULL, 'uploads/customers/1/customer_1772136812.png', '2026-02-23 11:51:21', '2026-03-02 18:42:33', NULL, NULL, NULL, NULL, NULL, 'savings', NULL, NULL, NULL, NULL, NULL),
('3', 'wqwe', 'Father', 'erqwerw', '4585854585', 'dineshkarthi11503@gmail.com', '4585854585', '', '12', 'yey', 'reryt', 'tetr', 'etrer', 'rtyrety', '252525', 'rtyerty', 'tyeryert', 'yeteyt', '265326532562', 'trert', '', '', '', '10000.00', '0', NULL, 'uploads/customers/1772090485_9537.jpeg', '2026-02-26 07:21:25', '2026-02-26 07:21:25', NULL, NULL, NULL, NULL, NULL, 'savings', NULL, NULL, NULL, NULL, NULL),
('4', 'munisamy', 'Mother', 'eweqw', '7845858585', 'dinesewe221@gmail.com', '7845858585', '', '32', 'rwer', 'werw', 'rterter', 'rer', 'terter', '859685', 'tertewr', 'rtewrt', 'ertewrt', '859685968596', 'ere', '', '', '', '10000.00', '1', 'note ', 'uploads/customers/1772187632_6220.jpeg', '2026-02-27 10:20:32', '2026-02-27 10:20:32', NULL, NULL, NULL, NULL, NULL, 'savings', NULL, NULL, NULL, NULL, NULL),
('5', 'Rajasekarlingam Periyasami', '', 'Saranya', '9390759599', 'ibdsa1986@gmail.com', '9390759599', '', '11', 'Unh', 'Hrgg', 'Rhyu', 'Hyt', 'Dinesg', '678898', 'Ghuj', 'Tuuu', 'Tghh', '111133334444', 'Yhu6', '', '', '', '5000000.00', '0', '', 'uploads/customers/1772206077_8090.jpg', '2026-02-27 15:27:57', '2026-02-27 15:27:57', NULL, NULL, NULL, NULL, NULL, 'savings', NULL, NULL, NULL, NULL, NULL),
('6', 'wrqw', 'Father', 'rewr', '8585858585', '', '8585858585', '', '12', 'qwr', 'rweqrwe', 'werwer', 'rwqerweq', 'rwerq', '124578', 'ewwe', 'werqwer', 'werrewq', '123212457845', 'wrqwre', 'werqw', '', '', '10000.00', '0', '', 'uploads/customers/6/customer_1772210541_8367.png', '2026-02-27 16:42:21', '2026-02-27 16:42:21', 'erqwerq', 'erqwerqer', 'erqerqwerwqe', '25252525252', 'sbin000012', 'current', '', NULL, NULL, NULL, NULL),
('7', 'WQWQ', 'Mother', 'WEQW', '4578457845', 'dedtere@gmail.com', '4578457845', 'QWEQ', '12', 'ewrq', 'rqwer', 'werwew', 'erwqer', 'rwqerwq', '785968', 'rqwer', 'erqwe', 'rqwerwqe', '124578985623', 'weqwe', 'wqeqw', 'weqwe', 'weqwe', '10000.00', '0', '', 'uploads/customers/7/customer_1772212403_4867.png', '2026-02-27 17:13:23', '2026-02-27 17:13:23', 'erqwer', 'rqwerwqe', 'erqwe', '45454545858', 'sbio000012', 'savings', '', NULL, NULL, NULL, NULL),
('8', 'saas', 'Father', 'qweqwq', '4585784857', 'dinesh11@gmail.com', '4585784857', 'wqw', '12', '3r23r', 'gsfg', 'gsfg', 'sdfg', 'fgsdfg', '125254', 'rwert', 'ertwert', 'trwert', '852963258963', 'wer', 'wrqw', 'eqwe', '', '100000.00', '0', '', 'uploads/customers/8/customer_1772213439_4274.jpeg', '2026-02-27 17:30:39', '2026-02-27 17:30:39', 'wertwrt', 'ertrtw', 'rtwrtw', '52525252634', 'sbin00012', 'current', '', NULL, NULL, NULL, NULL);

-- Structure for table `defect_details`
DROP TABLE IF EXISTS `defect_details`;
CREATE TABLE `defect_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `defect_name` varchar(150) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `defect_details`
INSERT INTO `defect_details` (`id`, `defect_name`, `created_at`, `updated_at`) VALUES 
('2', 'நெளிந்தது', '2026-02-24 06:14:52', '2026-02-24 06:14:52');

-- Structure for table `departments`
DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `department_name` varchar(100) NOT NULL,
  `status` tinyint(4) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `departments`
INSERT INTO `departments` (`id`, `department_name`, `status`, `created_at`) VALUES 
('1', 'Sales', '1', '2026-02-25 13:59:51'),
('2', 'Operations', '1', '2026-02-25 13:59:51'),
('3', 'Finance', '1', '2026-02-25 13:59:51'),
('4', 'Human Resources', '1', '2026-02-25 13:59:51'),
('5', 'IT', '1', '2026-02-25 13:59:51'),
('6', 'Administration', '1', '2026-02-25 13:59:51'),
('7', 'Accounts', '1', '2026-02-25 13:59:51'),
('8', 'Management', '1', '2026-02-25 13:59:51');

-- Structure for table `dynamic_interest`
DROP TABLE IF EXISTS `dynamic_interest`;
CREATE TABLE `dynamic_interest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_type` varchar(100) NOT NULL,
  `interest_type` varchar(150) NOT NULL,
  `from_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `to_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `months_1_3` decimal(5,2) NOT NULL DEFAULT 0.00,
  `months_4_6` decimal(5,2) NOT NULL DEFAULT 0.00,
  `months_7_9` decimal(5,2) NOT NULL DEFAULT 0.00,
  `months_10_12` decimal(5,2) NOT NULL DEFAULT 0.00,
  `above_1_year` decimal(5,2) NOT NULL DEFAULT 0.00,
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `dynamic_interest`
INSERT INTO `dynamic_interest` (`id`, `product_type`, `interest_type`, `from_amount`, `to_amount`, `months_1_3`, `months_4_6`, `months_7_9`, `months_10_12`, `above_1_year`, `status`, `created_at`, `updated_at`) VALUES 
('6', 'வெள்ளி', '2.5', '1.00', '1.00', '1.00', '5.50', '1.00', '1.00', '1.00', '1', '2026-02-25 06:58:44', '2026-02-25 06:59:41');

-- Structure for table `email_logs`
DROP TABLE IF EXISTS `email_logs`;
CREATE TABLE `email_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loan_id` int(11) NOT NULL,
  `receipt_number` varchar(20) NOT NULL,
  `customer_email` varchar(100) DEFAULT NULL,
  `status` enum('sent','failed','pending') DEFAULT 'pending',
  `error_message` text DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `loan_id` (`loan_id`),
  KEY `receipt_number` (`receipt_number`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `email_logs`
INSERT INTO `email_logs` (`id`, `loan_id`, `receipt_number`, `customer_email`, `status`, `error_message`, `sent_at`, `created_at`) VALUES 
('1', '11', '260302005', 'munus9404@gmail.com', 'sent', NULL, '2026-03-02 18:14:09', '2026-03-02 18:14:09'),
('2', '12', '260302006', 'munus9404@gmail.com', 'sent', NULL, '2026-03-02 18:16:39', '2026-03-02 18:16:39');

-- Structure for table `email_settings`
DROP TABLE IF EXISTS `email_settings`;
CREATE TABLE `email_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `smtp_host` varchar(255) NOT NULL,
  `smtp_port` int(11) NOT NULL,
  `smtp_username` varchar(255) NOT NULL,
  `smtp_password` varchar(255) NOT NULL,
  `smtp_from_email` varchar(255) NOT NULL,
  `smtp_from_name` varchar(255) NOT NULL,
  `smtp_secure` enum('tls','ssl') DEFAULT 'tls',
  `admin_email` varchar(255) NOT NULL,
  `notification_emails` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Structure for table `employee_documents`
DROP TABLE IF EXISTS `employee_documents`;
CREATE TABLE `employee_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `document_type` varchar(50) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `uploaded_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `employee_id` (`employee_id`),
  CONSTRAINT `employee_documents_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Structure for table `expense_details`
DROP TABLE IF EXISTS `expense_details`;
CREATE TABLE `expense_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receipt_number` int(11) NOT NULL,
  `date` date NOT NULL,
  `expense_type` varchar(150) NOT NULL,
  `detail` text DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT 'cash',
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `receipt_number` (`receipt_number`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `expense_details`
INSERT INTO `expense_details` (`id`, `receipt_number`, `date`, `expense_type`, `detail`, `payment_method`, `amount`, `status`, `created_at`, `updated_at`) VALUES 
('1', '41', '2026-01-14', 'สมัครสมัคร', 'สมัครสมัคร', 'cash', '50000.00', '1', '2026-03-02 21:41:47', '2026-03-02 21:41:47'),
('2', '39', '2025-12-12', 'คะแนนการจัดจ้าง', 'จุดสมัครปี 2025', 'bank', '15000.00', '1', '2026-03-02 21:41:47', '2026-03-02 21:41:47'),
('3', '42', '2026-03-02', 'கடை வாடைக', 'rent payment', 'cash', '50000.00', '1', '2026-03-02 21:42:39', '2026-03-02 21:42:39'),
('4', '43', '2026-03-02', 'Stationary', 'rent paid', 'cash', '45000.00', '1', '2026-03-02 21:44:38', '2026-03-02 21:44:38'),
('5', '44', '2026-03-02', 'Electric bill', 'rent payment', 'cash', '67780.00', '1', '2026-03-02 21:45:37', '2026-03-02 21:45:37'),
('6', '45', '2026-03-02', 'Salary', 'rent payment', 'cash', '80000.00', '1', '2026-03-02 21:45:57', '2026-03-02 21:45:57'),
('7', '46', '2026-03-03', 'கடை வாடைக', 'rent', 'cash', '10000.00', '1', '2026-03-03 06:59:16', '2026-03-03 06:59:16'),
('8', '47', '2026-03-03', 'Diwali bonus', 'diwali bonus', 'cash', '5000.00', '1', '2026-03-03 09:06:17', '2026-03-03 09:06:17');

-- Structure for table `expense_types`
DROP TABLE IF EXISTS `expense_types`;
CREATE TABLE `expense_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expense_type` varchar(150) NOT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `expense_types`
INSERT INTO `expense_types` (`id`, `expense_type`, `status`, `created_at`, `updated_at`) VALUES 
('1', 'சம்பளம்', '1', '2026-02-25 07:23:27', '2026-02-25 10:48:34'),
('2', 'Stationary', '1', '2026-02-25 07:23:27', '2026-02-25 07:23:27'),
('3', 'பூஜை', '1', '2026-02-25 07:23:27', '2026-02-25 07:23:27'),
('4', 'கடை வாடைக', '1', '2026-02-25 07:23:27', '2026-02-25 07:23:27'),
('5', 'Salary', '1', '2026-02-25 07:23:27', '2026-02-25 07:23:27'),
('6', 'பூ.அரிஜனை', '1', '2026-02-25 07:23:27', '2026-02-25 07:23:27'),
('7', 'Electric bill', '1', '2026-02-25 07:23:27', '2026-02-25 07:23:27'),
('8', 'Computer services', '1', '2026-02-25 07:23:27', '2026-02-25 07:23:27'),
('9', 'Diwali bonus', '1', '2026-02-25 07:23:27', '2026-02-25 07:23:27'),
('10', 'உண்டியல்', '1', '2026-02-25 07:23:27', '2026-02-25 07:23:27'),
('11', 'ஏலம்', '1', '2026-02-25 07:23:27', '2026-02-25 07:23:27');

-- Structure for table `fixed_interest`
DROP TABLE IF EXISTS `fixed_interest`;
CREATE TABLE `fixed_interest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_type` varchar(100) NOT NULL,
  `interest_type` varchar(150) NOT NULL,
  `upto_1_year` decimal(5,2) NOT NULL DEFAULT 0.00,
  `above_1_year` decimal(5,2) NOT NULL DEFAULT 0.00,
  `above_2_years` decimal(5,2) NOT NULL DEFAULT 0.00,
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `fixed_interest`
INSERT INTO `fixed_interest` (`id`, `product_type`, `interest_type`, `upto_1_year`, `above_1_year`, `above_2_years`, `status`, `created_at`, `updated_at`) VALUES 
('8', 'தங்கம்', 'வட்டி (3)', '1.00', '1.50', '2.00', '1', '2026-02-25 06:23:19', '2026-02-25 06:23:19'),
('9', 'gold', 'வட்டி (1.50)', '1.00', '1.50', '4.00', '1', '2026-02-25 06:24:12', '2026-02-25 06:24:35'),
('10', 'தங்கம்', 'வட்டி (2.50)', '1.00', '2.00', '2.00', '1', '2026-03-05 08:10:31', '2026-03-05 08:10:31');

-- Structure for table `gods_name`
DROP TABLE IF EXISTS `gods_name`;
CREATE TABLE `gods_name` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `investor_id` int(11) NOT NULL,
  `gods_name` varchar(150) NOT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `gods_name`
INSERT INTO `gods_name` (`id`, `investor_id`, `gods_name`, `status`, `created_at`, `updated_at`) VALUES 
('1', '1', 'Saibaba', '1', '2026-02-24 08:00:03', '2026-02-24 08:00:03'),
('2', '2', 'Muruga', '1', '2026-02-24 08:00:03', '2026-02-24 08:00:03'),
('3', '3', 'DINESH', '1', '2026-02-24 08:00:03', '2026-02-24 08:00:03');

-- Structure for table `interest_settings`
DROP TABLE IF EXISTS `interest_settings`;
CREATE TABLE `interest_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `interest_type` enum('daily','monthly','fixed','dynamic','amount_based') NOT NULL,
  `daily_monthly` enum('Daily','Monthly') DEFAULT 'Monthly',
  `rate` decimal(5,2) NOT NULL,
  `grace_days` int(11) DEFAULT 0,
  `penal_rate` decimal(5,2) DEFAULT 0.00,
  `fixed_dynamic` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `interest_settings`
INSERT INTO `interest_settings` (`id`, `interest_type`, `daily_monthly`, `rate`, `grace_days`, `penal_rate`, `fixed_dynamic`, `description`, `is_active`, `created_at`, `updated_at`) VALUES 
('38', 'monthly', 'Monthly', '2.20', '30', '2.00', 'fixed', '', '1', '2026-02-23 18:42:32', '2026-02-23 18:43:42'),
('39', 'monthly', 'Monthly', '1.50', '30', '0.00', 'fixed', '', '1', '2026-02-23 18:43:25', '2026-02-23 18:43:25'),
('40', 'daily', 'Monthly', '2.00', '20', '2.00', 'fixed', '', '1', '2026-02-25 05:55:40', '2026-02-25 05:55:40'),
('41', 'daily', 'Daily', '2.00', '30', '2.00', 'fixed', '', '1', '2026-03-05 08:09:16', '2026-03-05 08:09:38');

-- Structure for table `investment_returns`
DROP TABLE IF EXISTS `investment_returns`;
CREATE TABLE `investment_returns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `investment_return_id` int(11) NOT NULL,
  `return_date` date NOT NULL,
  `investment_no` int(11) NOT NULL,
  `investment_date` date NOT NULL,
  `investor_name` varchar(150) NOT NULL,
  `investment_type` varchar(150) DEFAULT NULL,
  `investment_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `payable_investment` decimal(15,2) NOT NULL DEFAULT 0.00,
  `interest_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `payable_interest` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total_days` int(11) DEFAULT 0,
  `payable_days` int(11) DEFAULT 0,
  `addon_id` varchar(50) DEFAULT NULL,
  `addon_date` date DEFAULT NULL,
  `addon_amount` decimal(15,2) DEFAULT 0.00,
  `remarks` text DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT 'cash',
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `investment_return_id` (`investment_return_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Structure for table `investment_types`
DROP TABLE IF EXISTS `investment_types`;
CREATE TABLE `investment_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `investment_type_name` varchar(150) NOT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `investment_types`
INSERT INTO `investment_types` (`id`, `investment_type_name`, `status`, `created_at`, `updated_at`) VALUES 
('1', 'கவராமிகள் கணக்கு', '1', '2026-02-24 08:05:26', '2026-02-24 08:05:26'),
('2', 'நடப்பு கணக்கு', '1', '2026-02-24 08:05:26', '2026-02-24 08:05:26'),
('3', 'பங்குமுகல் கணக்கு', '1', '2026-02-24 08:05:26', '2026-02-24 08:05:26'),
('4', 'வட்டி கணக்கு', '1', '2026-02-24 08:05:26', '2026-02-24 09:48:50');

-- Structure for table `investments`
DROP TABLE IF EXISTS `investments`;
CREATE TABLE `investments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `investment_no` int(11) NOT NULL,
  `investment_date` date NOT NULL,
  `investment_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `interest` decimal(15,2) NOT NULL DEFAULT 0.00,
  `investment_type` varchar(150) NOT NULL,
  `investor_name` varchar(150) NOT NULL,
  `guardian_type` varchar(50) DEFAULT NULL,
  `guardian_name` varchar(150) DEFAULT NULL,
  `mobile_number` varchar(15) NOT NULL,
  `gods_name` varchar(150) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT 'cash',
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `investment_no` (`investment_no`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `investments`
INSERT INTO `investments` (`id`, `investment_no`, `investment_date`, `investment_amount`, `interest`, `investment_type`, `investor_name`, `guardian_type`, `guardian_name`, `mobile_number`, `gods_name`, `payment_method`, `status`, `created_at`, `updated_at`) VALUES 
('3', '1', '2026-02-24', '1000.00', '1.00', 'கவராமிகள் கணக்கு', 'அத்விக்', 'Mother', 'dinesh', '7584857845', '', 'cash', '1', '2026-02-24 10:00:34', '2026-02-24 10:00:34');

-- Structure for table `investors`
DROP TABLE IF EXISTS `investors`;
CREATE TABLE `investors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `investor_id` int(11) NOT NULL,
  `investor_name` varchar(150) NOT NULL,
  `guardian_type` varchar(50) NOT NULL,
  `guardian_name` varchar(150) NOT NULL,
  `mobile_number` varchar(15) NOT NULL,
  `alternate_mobile` varchar(15) DEFAULT NULL,
  `investor_address` text DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `investor_id` (`investor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `investors`
INSERT INTO `investors` (`id`, `investor_id`, `investor_name`, `guardian_type`, `guardian_name`, `mobile_number`, `alternate_mobile`, `investor_address`, `status`, `created_at`, `updated_at`) VALUES 
('1', '1', 'அத்விக்', 'Father', 'பிரதீஷ்', '7373888777', '', 'Chennai', '1', '2026-02-24 08:13:04', '2026-02-24 08:13:04'),
('2', '2', 'dks', 'Father', 'srinath', '4578485784', '', '', '1', '2026-02-24 08:14:38', '2026-02-24 08:14:46');

-- Structure for table `invoice`
DROP TABLE IF EXISTS `invoice`;
CREATE TABLE `invoice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(50) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `loan_id` int(11) DEFAULT NULL,
  `invoice_date` date NOT NULL,
  `total_amount` decimal(15,2) NOT NULL,
  `status` enum('pending','paid','cancelled') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `customer_id` (`customer_id`),
  KEY `loan_id` (`loan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Structure for table `karat_details`
DROP TABLE IF EXISTS `karat_details`;
CREATE TABLE `karat_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_type` varchar(100) NOT NULL,
  `karat` decimal(4,2) NOT NULL,
  `max_value_per_gram` decimal(12,2) NOT NULL,
  `loan_value_per_gram` decimal(12,2) NOT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `karat_details`
INSERT INTO `karat_details` (`id`, `product_type`, `karat`, `max_value_per_gram`, `loan_value_per_gram`, `status`, `created_at`, `updated_at`) VALUES 
('5', 'தங்கம்', '21.00', '6500.00', '6000.00', '1', '2026-02-24 07:27:31', '2026-02-24 07:27:31'),
('6', 'தங்கம்', '24.00', '120000.00', '6800.00', '1', '2026-02-24 07:27:31', '2026-02-24 07:27:31');

-- Structure for table `loan_items`
DROP TABLE IF EXISTS `loan_items`;
CREATE TABLE `loan_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loan_id` int(11) NOT NULL,
  `jewel_name` varchar(150) NOT NULL,
  `karat` decimal(4,2) NOT NULL,
  `defect_details` text DEFAULT NULL,
  `stone_details` text DEFAULT NULL,
  `net_weight` decimal(10,3) NOT NULL,
  `quantity` int(11) DEFAULT 1,
  `photo_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `loan_id` (`loan_id`),
  CONSTRAINT `loan_items_ibfk_1` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `loan_items`
INSERT INTO `loan_items` (`id`, `loan_id`, `jewel_name`, `karat`, `defect_details`, `stone_details`, `net_weight`, `quantity`, `photo_path`) VALUES 
('1', '1', 'பேபி மொதிரம்', '21.00', 'நெளிந்தது', '2 கல்', '0.500', '1', NULL),
('2', '2', 'வேழ்ஸ் மொதிரம்', '21.00', '', '', '10.000', '1', NULL),
('3', '3', 'hi', '21.00', 'நெளிந்தது', '2 கல்', '20.000', '1', NULL),
('8', '4', 'பேபி மொதிரம்', '21.00', '', '', '10.000', '1', 'uploads/loan_items/4/jewel_1_1772136812.jpeg'),
('9', '4', 'வேழ்ஸ் மொதிரம்', '21.00', '', '', '10.000', '1', 'uploads/loan_items/4/jewel_2_1772136812.jpeg'),
('10', '5', 'hi', '21.00', '', '', '5.000', '1', NULL),
('11', '5', 'பேபி மொதிரம்', '21.00', '', '', '4.000', '1', NULL),
('12', '6', 'பேபி மொதிரம்', '21.00', 'நெளிந்தது', '2 கல்', '4.000', '1', 'uploads/loan_items/6/jewel_1_1772206894.jpg'),
('13', '6', 'வேழ்ஸ் மொதிரம்', '24.00', '', '', '16.000', '1', 'uploads/loan_items/6/jewel_2_1772206894.jpg'),
('14', '7', 'பேபி மொதிரம்', '21.00', '', '', '8.000', '1', 'uploads/loan_items/7/jewel_1_1772473171.jpeg'),
('15', '8', 'பேபி மொதிரம்', '21.00', '', '', '8.000', '1', 'uploads/loan_items/8/jewel_1_1772473301.jpeg'),
('16', '9', 'பேபி மொதிரம்', '21.00', '', '', '8.000', '1', 'uploads/loan_items/9/jewel_1_1772473574.jpeg'),
('17', '10', 'பேபி மொதிரம்', '21.00', '', '', '8.000', '1', NULL),
('18', '11', 'பேபி மொதிரம்', '21.00', '', '', '8.000', '1', 'uploads/loan_items/11/jewel_1_1772475248.jpeg'),
('19', '12', 'hi', '21.00', '', '', '7.000', '1', NULL),
('20', '13', 'பேபி மொதிரம்', '21.00', '', '', '8.000', '1', NULL),
('21', '14', 'பேபி மொதிரம்', '21.00', '', '', '19.000', '1', NULL);

-- Structure for table `loans`
DROP TABLE IF EXISTS `loans`;
CREATE TABLE `loans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receipt_number` varchar(20) NOT NULL,
  `receipt_date` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `gross_weight` decimal(10,3) NOT NULL,
  `net_weight` decimal(10,3) NOT NULL,
  `product_value` decimal(12,2) NOT NULL,
  `loan_amount` decimal(12,2) NOT NULL,
  `interest_type` enum('daily','monthly','fixed','dynamic','amount_based') NOT NULL,
  `interest_amount` decimal(12,2) DEFAULT 0.00,
  `receipt_charge` decimal(10,2) DEFAULT 0.00,
  `employee_id` int(11) NOT NULL,
  `status` enum('open','closed','auctioned','reloan','defaulted') DEFAULT 'open',
  `close_date` date DEFAULT NULL,
  `payable_interest` decimal(12,2) DEFAULT 0.00,
  `payable_loan_amount` decimal(12,2) DEFAULT NULL,
  `discount` decimal(12,2) DEFAULT 0.00,
  `round_off` decimal(10,2) DEFAULT 0.00,
  `d_namuna` tinyint(1) DEFAULT 0,
  `others` tinyint(1) DEFAULT 0,
  `last_overdue_calculated` date DEFAULT NULL,
  `total_overdue_amount` decimal(12,2) DEFAULT 0.00,
  `last_interest_paid_date` date DEFAULT NULL,
  `reloan` tinyint(1) DEFAULT 0,
  `photo_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `receipt_number` (`receipt_number`),
  KEY `customer_id` (`customer_id`),
  KEY `employee_id` (`employee_id`),
  KEY `idx_status` (`status`),
  KEY `idx_receipt` (`receipt_number`),
  KEY `idx_overdue_status` (`last_overdue_calculated`,`total_overdue_amount`),
  CONSTRAINT `loans_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `loans_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `loans`
INSERT INTO `loans` (`id`, `receipt_number`, `receipt_date`, `customer_id`, `gross_weight`, `net_weight`, `product_value`, `loan_amount`, `interest_type`, `interest_amount`, `receipt_charge`, `employee_id`, `status`, `close_date`, `payable_interest`, `payable_loan_amount`, `discount`, `round_off`, `d_namuna`, `others`, `last_overdue_calculated`, `total_overdue_amount`, `last_interest_paid_date`, `reloan`, `photo_path`, `created_at`, `updated_at`) VALUES 
('1', '260225001', '0000-00-00', '1', '0.550', '0.500', '10000.00', '100000.00', '', '2.00', '400.00', '1', 'closed', '2026-02-26', '0.00', NULL, '0.00', '0.00', '0', '0', NULL, '0.00', NULL, '0', NULL, '2026-02-25 16:13:58', '2026-02-26 10:35:05'),
('2', '260226001', '0000-00-00', '3', '11.000', '10.000', '100.00', '1000.00', '', '2.00', '100.00', '1', 'open', NULL, '0.00', NULL, '0.00', '0.00', '0', '0', NULL, '0.00', NULL, '0', NULL, '2026-02-26 07:33:16', '2026-02-26 07:33:16'),
('3', '260226002', '2026-02-26', '1', '22.000', '20.000', '2000.00', '10000.00', 'monthly', NULL, '500.00', '1', 'closed', '2026-02-26', '0.00', NULL, '10.00', '20.00', '0', '0', NULL, '0.00', NULL, '0', NULL, '2026-02-26 09:10:09', '2026-02-26 12:53:42'),
('4', '260226003', '2026-02-26', '1', '22.000', '20.000', '14930.00', '100000.00', '', '2.00', '400.00', '1', 'open', NULL, '0.00', NULL, '0.00', '0.00', '0', '0', NULL, '0.00', NULL, '0', NULL, '2026-02-26 17:13:22', '2026-02-26 20:13:32'),
('5', '260227001', '2026-02-27', '1', '9.000', '9.000', '126000.00', '126000.00', 'monthly', '2.20', '200.00', '1', 'closed', '2026-02-27', '0.00', NULL, '0.00', '0.00', '0', '0', NULL, '0.00', NULL, '0', NULL, '2026-02-27 10:48:43', '2026-02-27 16:03:28'),
('6', '260227002', '2026-02-27', '5', '22.000', '20.000', '223500.00', '223500.00', 'daily', '2.00', '0.00', '1', 'open', NULL, '0.00', NULL, '0.00', '0.00', '0', '0', NULL, '0.00', NULL, '0', NULL, '2026-02-27 15:41:34', '2026-02-27 15:41:34'),
('7', '260302001', '2026-03-02', '1', '8.000', '8.000', '89400.00', '89400.00', 'daily', '2.00', '0.00', '1', 'open', NULL, '0.00', NULL, '0.00', '0.00', '0', '0', '2026-03-03', '0.00', NULL, '0', NULL, '2026-03-02 17:39:31', '2026-03-03 07:34:06'),
('8', '260302002', '2026-03-02', '1', '8.000', '8.000', '89400.00', '89400.00', 'daily', '2.00', '0.00', '1', 'open', NULL, '0.00', NULL, '0.00', '0.00', '0', '0', NULL, '0.00', '2026-03-03', '0', NULL, '2026-03-02 17:41:41', '2026-03-03 09:59:08'),
('9', '260302003', '2026-03-02', '1', '8.000', '8.000', '89400.00', '89400.00', 'daily', '2.00', '0.00', '1', 'closed', '2026-03-03', '0.00', NULL, '0.00', '0.00', '0', '0', NULL, '0.00', NULL, '0', NULL, '2026-03-02 17:46:14', '2026-03-03 06:20:57'),
('10', '260302004', '2026-03-02', '1', '8.000', '8.000', '89400.00', '89400.00', 'daily', '2.00', '0.00', '1', 'open', NULL, '0.00', NULL, '0.00', '0.00', '0', '0', '2026-03-03', '0.00', '2026-03-03', '0', NULL, '2026-03-02 18:08:21', '2026-03-03 10:41:34'),
('11', '260302005', '2026-03-02', '1', '8.000', '8.000', '89400.00', '89400.00', 'daily', '2.00', '0.00', '1', 'open', NULL, '0.00', NULL, '0.00', '0.00', '0', '0', NULL, '0.00', NULL, '0', NULL, '2026-03-02 18:14:08', '2026-03-02 18:14:08'),
('12', '260302006', '2026-03-02', '1', '7.000', '7.000', '78225.00', '78225.00', 'daily', '2.00', '0.00', '1', 'open', NULL, '0.00', NULL, '0.00', '0.00', '0', '0', NULL, '0.00', NULL, '0', NULL, '2026-03-02 18:16:39', '2026-03-02 18:16:39'),
('13', '260302007', '2026-03-03', '1', '8.000', '8.000', '89400.00', '89400.00', 'daily', '2.00', '0.00', '1', 'closed', '2026-03-03', '0.00', NULL, '0.00', '0.00', '0', '0', NULL, '0.00', NULL, '0', NULL, '2026-03-02 18:41:32', '2026-03-03 06:20:57'),
('14', '260302008', '2026-03-03', '1', '20.000', '19.000', '212325.00', '212325.00', 'daily', '2.00', '0.00', '1', 'closed', '2026-03-03', '0.00', NULL, '0.00', '0.00', '0', '0', NULL, '0.00', NULL, '0', NULL, '2026-03-02 18:43:22', '2026-03-03 06:20:57');

-- Structure for table `overdue_payments`
DROP TABLE IF EXISTS `overdue_payments`;
CREATE TABLE `overdue_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loan_id` int(11) NOT NULL,
  `payment_id` int(11) DEFAULT NULL,
  `overdue_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `overdue_date` date NOT NULL,
  `paid_date` date DEFAULT NULL,
  `status` enum('pending','paid','waived') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `loan_id` (`loan_id`),
  KEY `payment_id` (`payment_id`),
  KEY `idx_overdue_status` (`status`,`overdue_date`),
  CONSTRAINT `overdue_payments_ibfk_1` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `overdue_payments_ibfk_2` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Structure for table `payment_method_settings`
DROP TABLE IF EXISTS `payment_method_settings`;
CREATE TABLE `payment_method_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_type_id` int(11) NOT NULL,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` enum('text','number','boolean','json') DEFAULT 'text',
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `payment_setting` (`payment_type_id`,`setting_key`),
  KEY `payment_type_id` (`payment_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Structure for table `payment_types`
DROP TABLE IF EXISTS `payment_types`;
CREATE TABLE `payment_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_code` varchar(20) NOT NULL,
  `payment_name` varchar(100) NOT NULL,
  `display_name` varchar(100) NOT NULL,
  `icon` varchar(50) DEFAULT 'bi-cash',
  `color` varchar(20) DEFAULT '#48bb78',
  `is_active` tinyint(1) DEFAULT 1,
  `is_default` tinyint(1) DEFAULT 0,
  `requires_reference` tinyint(1) DEFAULT 0,
  `requires_bank` tinyint(1) DEFAULT 0,
  `requires_account` tinyint(1) DEFAULT 0,
  `requires_cheque_details` tinyint(1) DEFAULT 0,
  `requires_upi_details` tinyint(1) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `payment_code` (`payment_code`),
  KEY `is_active` (`is_active`),
  KEY `sort_order` (`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `payment_types`
INSERT INTO `payment_types` (`id`, `payment_code`, `payment_name`, `display_name`, `icon`, `color`, `is_active`, `is_default`, `requires_reference`, `requires_bank`, `requires_account`, `requires_cheque_details`, `requires_upi_details`, `sort_order`, `description`, `created_at`, `updated_at`) VALUES 
('1', 'cash', 'Cash', 'Cash Payment', 'bi-cash', '#48bb78', '1', '1', '0', '0', '0', '0', '0', '1', NULL, '2026-03-05 06:25:47', '2026-03-05 06:25:47'),
('2', 'bank', 'Bank Transfer', 'Bank Transfer', 'bi-bank', '#4299e1', '1', '0', '1', '0', '0', '0', '0', '2', NULL, '2026-03-05 06:25:47', '2026-03-05 06:25:47'),
('3', 'upi', 'UPI', 'UPI Payment', 'bi-phone', '#9f7aea', '1', '0', '1', '0', '0', '0', '0', '3', NULL, '2026-03-05 06:25:47', '2026-03-05 06:25:47'),
('4', 'cheque', 'Cheque', 'Cheque Payment', 'bi-file-text', '#f56565', '1', '0', '1', '0', '0', '0', '0', '4', NULL, '2026-03-05 06:25:47', '2026-03-05 06:25:47'),
('5', 'card', 'Card', 'Card Payment', 'bi-credit-card', '#ed8936', '1', '0', '1', '0', '0', '0', '0', '5', NULL, '2026-03-05 06:25:47', '2026-03-05 06:25:47'),
('6', 'other', 'Other', 'Other Payment', 'bi-three-dots', '#718096', '1', '0', '1', '0', '0', '0', '0', '6', NULL, '2026-03-05 06:25:47', '2026-03-05 06:25:47');

-- Structure for table `payments`
DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loan_id` int(11) NOT NULL,
  `receipt_number` varchar(20) NOT NULL,
  `payment_date` date NOT NULL,
  `principal_amount` decimal(12,2) DEFAULT 0.00,
  `interest_amount` decimal(12,2) DEFAULT 0.00,
  `total_amount` decimal(12,2) NOT NULL,
  `payment_mode` enum('cash','bank','upi','other') DEFAULT 'cash',
  `employee_id` int(11) NOT NULL,
  `remarks` text DEFAULT NULL,
  `includes_overdue` tinyint(1) DEFAULT 0,
  `overdue_amount_paid` decimal(12,2) DEFAULT 0.00,
  `overdue_charge` decimal(12,2) DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `loan_id` (`loan_id`),
  KEY `employee_id` (`employee_id`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `payments`
INSERT INTO `payments` (`id`, `loan_id`, `receipt_number`, `payment_date`, `principal_amount`, `interest_amount`, `total_amount`, `payment_mode`, `employee_id`, `remarks`, `includes_overdue`, `overdue_amount_paid`, `overdue_charge`, `created_at`) VALUES 
('1', '1', 'CLS2602260001', '2026-02-26', '100000.00', '0.00', '100400.00', '', '1', '', '0', '0.00', '0.00', '2026-02-26 10:35:05'),
('2', '3', 'BLK2602260002', '2026-02-26', '10000.00', '0.00', '10510.00', '', '1', '', '0', '0.00', '0.00', '2026-02-26 12:53:42'),
('3', '4', 'INT2602270001', '2026-02-27', '0.00', '66.67', '66.67', '', '1', 'Interest Collection', '0', '0.00', '0.00', '2026-02-27 15:57:44'),
('4', '4', 'INT2602270002', '2026-02-27', '0.00', '66.67', '66.67', '', '1', 'Interest Collection', '0', '0.00', '0.00', '2026-02-27 15:59:02'),
('5', '5', 'CLS2602270003', '2026-02-27', '126000.00', '0.00', '126200.00', '', '1', '', '0', '0.00', '0.00', '2026-02-27 16:03:28'),
('6', '6', 'PRN2602270004', '2026-02-27', '23500.00', '0.00', '23500.00', '', '1', 'Principal Payment', '0', '0.00', '0.00', '2026-02-27 19:32:18'),
('7', '13', 'BLK2603030001', '2026-03-03', '89400.00', '0.00', '89400.00', '', '1', '', '0', '0.00', '0.00', '2026-03-03 06:20:57'),
('8', '14', 'BLK2603030002', '2026-03-03', '212325.00', '0.00', '212325.00', '', '1', '', '0', '0.00', '0.00', '2026-03-03 06:20:57'),
('9', '9', 'BLK2603030003', '2026-03-03', '89400.00', '0.00', '89400.00', '', '1', '', '0', '0.00', '0.00', '2026-03-03 06:20:57'),
('10', '7', 'INT2603030004', '2026-03-03', '0.00', '59.60', '59.60', '', '1', 'Interest Collection', '0', '0.00', '0.00', '2026-03-03 06:26:06'),
('13', '8', 'INT2603030005', '2026-03-03', '0.00', '59.60', '69.60', '', '1', 'Interest Collection', '0', '0.00', '0.00', '2026-03-03 09:59:08'),
('14', '10', 'CHG2603030006', '2026-03-03', '0.00', '59.60', '79.60', '', '1', 'Interest Collection', '1', '0.00', '20.00', '2026-03-03 10:41:34');

-- Structure for table `product_names`
DROP TABLE IF EXISTS `product_names`;
CREATE TABLE `product_names` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_type` varchar(100) NOT NULL,
  `jewel_name` varchar(150) NOT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `product_names`
INSERT INTO `product_names` (`id`, `product_type`, `jewel_name`, `status`, `created_at`, `updated_at`) VALUES 
('8', 'தங்கம்', 'பேபி மொதிரம்', '1', '2026-02-24 07:32:01', '2026-02-24 07:32:01'),
('9', 'தங்கம்', 'வேழ்ஸ் மொதிரம்', '1', '2026-02-24 07:32:01', '2026-02-24 07:32:01'),
('10', 'வெள்ளி', 'hi', '1', '2026-02-24 07:32:38', '2026-02-24 07:32:38');

-- Structure for table `product_types`
DROP TABLE IF EXISTS `product_types`;
CREATE TABLE `product_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_type` varchar(100) NOT NULL,
  `auction_type` varchar(50) NOT NULL,
  `print_color` varchar(50) NOT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `product_types`
INSERT INTO `product_types` (`id`, `product_type`, `auction_type`, `print_color`, `status`, `created_at`, `updated_at`) VALUES 
('1', 'தங்கம்', 'Karat', 'Black', '1', '2026-02-24 07:38:35', '2026-02-24 07:38:35'),
('2', 'வெள்ளி', 'Value', 'Blue', '1', '2026-02-24 07:38:35', '2026-02-24 07:38:35'),
('3', 'silver', 'Karat', 'Blue', '1', '2026-02-24 07:39:05', '2026-02-24 07:39:05');

-- Structure for table `product_value_settings`
DROP TABLE IF EXISTS `product_value_settings`;
CREATE TABLE `product_value_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_type` varchar(100) NOT NULL,
  `total_value_per_gram` decimal(10,2) NOT NULL DEFAULT 0.00,
  `percentage` decimal(5,2) NOT NULL DEFAULT 0.00,
  `status` tinyint(4) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_product_type` (`product_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `product_value_settings`
INSERT INTO `product_value_settings` (`id`, `product_type`, `total_value_per_gram`, `percentage`, `status`, `created_at`, `updated_at`) VALUES 
('1', 'தங்கம்', '14900.00', '75.00', '1', '2026-02-27 08:17:13', '2026-02-27 15:31:57');

-- Structure for table `stock_dividends`
DROP TABLE IF EXISTS `stock_dividends`;
CREATE TABLE `stock_dividends` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_id` int(11) NOT NULL,
  `declaration_date` date NOT NULL,
  `ex_date` date NOT NULL,
  `record_date` date NOT NULL,
  `payment_date` date DEFAULT NULL,
  `dividend_per_share` decimal(10,2) NOT NULL,
  `total_amount` decimal(15,2) NOT NULL,
  `tax_amount` decimal(10,2) DEFAULT NULL,
  `net_amount` decimal(15,2) NOT NULL,
  `status` enum('declared','paid','pending') DEFAULT 'pending',
  `remarks` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `stock_id` (`stock_id`),
  KEY `ex_date` (`ex_date`),
  KEY `payment_date` (`payment_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Structure for table `stock_transactions`
DROP TABLE IF EXISTS `stock_transactions`;
CREATE TABLE `stock_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_id` int(11) NOT NULL,
  `transaction_date` date NOT NULL,
  `transaction_type` enum('buy','sell','dividend','bonus','split') NOT NULL,
  `quantity` decimal(15,3) NOT NULL,
  `price` decimal(15,2) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `brokerage` decimal(10,2) DEFAULT NULL,
  `net_amount` decimal(15,2) NOT NULL,
  `remarks` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `stock_id` (`stock_id`),
  KEY `transaction_date` (`transaction_date`),
  KEY `transaction_type` (`transaction_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Structure for table `stone_details`
DROP TABLE IF EXISTS `stone_details`;
CREATE TABLE `stone_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stone_name` varchar(150) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `stone_details`
INSERT INTO `stone_details` (`id`, `stone_name`, `created_at`, `updated_at`) VALUES 
('7', '3 கல்', '2026-02-24 06:01:47', '2026-03-05 09:48:51'),
('9', 'stone', '2026-02-24 06:05:39', '2026-03-05 09:49:00');

-- Structure for table `upi_apps`
DROP TABLE IF EXISTS `upi_apps`;
CREATE TABLE `upi_apps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_name` varchar(100) NOT NULL,
  `app_code` varchar(50) NOT NULL,
  `icon` varchar(50) DEFAULT 'bi-phone',
  `color` varchar(20) DEFAULT '#9f7aea',
  `website` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `is_default` tinyint(1) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_code` (`app_code`),
  KEY `is_active` (`is_active`),
  KEY `sort_order` (`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `upi_apps`
INSERT INTO `upi_apps` (`id`, `app_name`, `app_code`, `icon`, `color`, `website`, `description`, `is_active`, `is_default`, `sort_order`, `created_at`, `updated_at`) VALUES 
('1', 'Google Pay', 'googlepay', 'bi-google', '#4285F4', 'https://pay.google.com', NULL, '1', '0', '1', '2026-03-05 06:34:03', '2026-03-05 06:34:03'),
('2', 'PhonePe', 'phonepe', 'bi-phone', '#5F259F', 'https://www.phonepe.com', NULL, '1', '0', '2', '2026-03-05 06:34:03', '2026-03-05 06:34:03'),
('3', 'Paytm', 'paytm', 'bi-cash', '#00BAF2', 'https://paytm.com', NULL, '1', '0', '3', '2026-03-05 06:34:03', '2026-03-05 06:34:03'),
('4', 'Amazon Pay', 'amazonpay', 'bi-amazon', '#FF9900', 'https://www.amazonpay.in', NULL, '1', '0', '4', '2026-03-05 06:34:03', '2026-03-05 06:34:03'),
('5', 'BHIM', 'bhim', 'bi-bank', '#004C8F', 'https://www.bhimupi.org.in', NULL, '1', '0', '5', '2026-03-05 06:34:03', '2026-03-05 06:34:03'),
('6', 'WhatsApp Pay', 'whatsapp', 'bi-whatsapp', '#25D366', 'https://pay.whatsapp.com', NULL, '1', '0', '6', '2026-03-05 06:34:03', '2026-03-05 06:34:03'),
('7', 'Other UPI', 'other', 'bi-three-dots', '#718096', NULL, NULL, '1', '0', '7', '2026-03-05 06:34:03', '2026-03-05 06:34:03');

-- Structure for table `upi_ids`
DROP TABLE IF EXISTS `upi_ids`;
CREATE TABLE `upi_ids` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `upi_id` varchar(100) NOT NULL,
  `account_holder` varchar(150) NOT NULL,
  `app_id` int(11) DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `qr_code_path` varchar(255) DEFAULT NULL,
  `is_primary` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `daily_limit` decimal(15,2) DEFAULT NULL,
  `transaction_limit` decimal(15,2) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `upi_id` (`upi_id`),
  KEY `app_id` (`app_id`),
  KEY `bank_id` (`bank_id`),
  KEY `is_primary` (`is_primary`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Structure for table `upi_transactions`
DROP TABLE IF EXISTS `upi_transactions`;
CREATE TABLE `upi_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `upi_id` varchar(100) NOT NULL,
  `transaction_id` varchar(100) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `payer_name` varchar(150) DEFAULT NULL,
  `payer_vpa` varchar(100) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `status` enum('success','pending','failed') DEFAULT 'pending',
  `payment_id` int(11) DEFAULT NULL,
  `loan_id` int(11) DEFAULT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_id` (`transaction_id`),
  KEY `upi_id` (`upi_id`),
  KEY `status` (`status`),
  KEY `payment_id` (`payment_id`),
  KEY `loan_id` (`loan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Structure for table `user_permissions`
DROP TABLE IF EXISTS `user_permissions`;
CREATE TABLE `user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `module` varchar(100) NOT NULL,
  `action` varchar(50) NOT NULL,
  `allowed` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_module_action` (`user_id`,`module`,`action`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_permissions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Structure for table `users`
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `role` enum('admin','sale','manager','accountant') NOT NULL DEFAULT 'sale',
  `status` enum('active','inactive') DEFAULT 'active',
  `mobile` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `marital_status` varchar(20) DEFAULT NULL,
  `blood_group` varchar(5) DEFAULT NULL,
  `emergency_contact` varchar(15) DEFAULT NULL,
  `emergency_contact_name` varchar(100) DEFAULT NULL,
  `emergency_relation` varchar(50) DEFAULT NULL,
  `address_line1` varchar(255) DEFAULT NULL,
  `address_line2` varchar(255) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `pincode` varchar(10) DEFAULT NULL,
  `country` varchar(100) DEFAULT 'India',
  `permanent_address_same` tinyint(1) DEFAULT 1,
  `permanent_address_line1` varchar(255) DEFAULT NULL,
  `permanent_address_line2` varchar(255) DEFAULT NULL,
  `permanent_city` varchar(100) DEFAULT NULL,
  `permanent_state` varchar(100) DEFAULT NULL,
  `permanent_pincode` varchar(10) DEFAULT NULL,
  `permanent_country` varchar(100) DEFAULT 'India',
  `employee_id` varchar(50) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `designation` varchar(100) DEFAULT NULL,
  `joining_date` date DEFAULT NULL,
  `confirmation_date` date DEFAULT NULL,
  `employment_type` varchar(50) DEFAULT 'full_time',
  `reporting_manager` varchar(100) DEFAULT NULL,
  `work_location` varchar(255) DEFAULT NULL,
  `shift_timing` varchar(50) DEFAULT NULL,
  `weekly_off` varchar(20) DEFAULT 'sunday',
  `total_experience_years` int(11) DEFAULT 0,
  `total_experience_months` int(11) DEFAULT 0,
  `previous_company` varchar(255) DEFAULT NULL,
  `previous_designation` varchar(100) DEFAULT NULL,
  `previous_experience_years` int(11) DEFAULT 0,
  `previous_experience_months` int(11) DEFAULT 0,
  `highest_qualification` varchar(50) DEFAULT NULL,
  `university` varchar(255) DEFAULT NULL,
  `year_of_passing` int(11) DEFAULT NULL,
  `percentage` decimal(5,2) DEFAULT NULL,
  `skills` text DEFAULT NULL,
  `certifications` text DEFAULT NULL,
  `account_holder_name` varchar(255) DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `branch_name` varchar(255) DEFAULT NULL,
  `account_number` varchar(50) DEFAULT NULL,
  `ifsc_code` varchar(20) DEFAULT NULL,
  `micr_code` varchar(20) DEFAULT NULL,
  `account_type` varchar(20) DEFAULT 'savings',
  `upi_id` varchar(100) DEFAULT NULL,
  `pan_number` varchar(10) DEFAULT NULL,
  `aadhar_number` varchar(12) DEFAULT NULL,
  `basic_salary` decimal(10,2) DEFAULT NULL,
  `hra` decimal(10,2) DEFAULT NULL,
  `conveyance` decimal(10,2) DEFAULT NULL,
  `medical_allowance` decimal(10,2) DEFAULT NULL,
  `special_allowance` decimal(10,2) DEFAULT NULL,
  `bonus` decimal(10,2) DEFAULT NULL,
  `pf_number` varchar(50) DEFAULT NULL,
  `esi_number` varchar(50) DEFAULT NULL,
  `uan_number` varchar(50) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `employee_photo` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_role` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `users`
INSERT INTO `users` (`id`, `username`, `password`, `name`, `role`, `status`, `mobile`, `email`, `date_of_birth`, `gender`, `marital_status`, `blood_group`, `emergency_contact`, `emergency_contact_name`, `emergency_relation`, `address_line1`, `address_line2`, `city`, `state`, `pincode`, `country`, `permanent_address_same`, `permanent_address_line1`, `permanent_address_line2`, `permanent_city`, `permanent_state`, `permanent_pincode`, `permanent_country`, `employee_id`, `department`, `designation`, `joining_date`, `confirmation_date`, `employment_type`, `reporting_manager`, `work_location`, `shift_timing`, `weekly_off`, `total_experience_years`, `total_experience_months`, `previous_company`, `previous_designation`, `previous_experience_years`, `previous_experience_months`, `highest_qualification`, `university`, `year_of_passing`, `percentage`, `skills`, `certifications`, `account_holder_name`, `bank_name`, `branch_name`, `account_number`, `ifsc_code`, `micr_code`, `account_type`, `upi_id`, `pan_number`, `aadhar_number`, `basic_salary`, `hra`, `conveyance`, `medical_allowance`, `special_allowance`, `bonus`, `pf_number`, `esi_number`, `uan_number`, `branch_id`, `employee_photo`, `created_at`, `updated_at`, `is_active`) VALUES 
('1', 'admin', '$2y$10$Xyhy2CymPK6tX1/dpOVoj.bOj0M0a1sr/ETxBeXR0KYF.QbLgO52e', 'Administrator', 'admin', 'active', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'India', '1', NULL, NULL, NULL, NULL, NULL, 'India', NULL, NULL, NULL, NULL, NULL, 'full_time', NULL, NULL, NULL, 'sunday', '0', '0', NULL, NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'savings', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-02-23 07:09:01', '2026-02-23 08:55:25', '1'),
('5', 'dinesh', '$2y$10$DXXDi1NNFccbINdlILwpGeZ0DkvKwTtGE42nV8SOKfqh/8SxIKCR.', 'dinesh dk', 'admin', 'active', '4578457845', 'dinesh@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'India', '1', NULL, NULL, NULL, NULL, NULL, 'India', NULL, NULL, NULL, NULL, NULL, 'full_time', NULL, NULL, NULL, 'sunday', '0', '0', NULL, NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'savings', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, '2026-02-23 10:38:37', '2026-02-23 10:38:37', '1'),
('7', 'srinath', '$2y$10$V5BDh0KBqc5irHeOZ//33u0Jk984dmjmZQxMWDA56MzxOcrnPkpnm', 'srinath D', 'admin', 'active', '7658595645', 'dinesh11@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'India', '1', NULL, NULL, NULL, NULL, NULL, 'India', NULL, NULL, NULL, NULL, NULL, 'full_time', NULL, NULL, NULL, 'sunday', '0', '0', NULL, NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'savings', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, '2026-02-23 11:25:16', '2026-02-23 11:25:16', '1'),
('8', 'abi', '$2y$10$L3107DkOSHOxHmOqRMpt.uaHcumrQirtXvhMC7bJhJcI1j3eXe/Xi', 'dineshabi', 'sale', 'active', '7584857845', 'dinesh11@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'India', '1', NULL, NULL, NULL, NULL, NULL, 'India', NULL, NULL, NULL, NULL, NULL, 'full_time', NULL, NULL, NULL, 'sunday', '0', '0', NULL, NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'savings', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'uploads/employees/emp_1771846570_7344.png', '2026-02-23 11:36:11', '2026-02-23 11:45:14', '1'),
('9', 'testuser', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Test User', 'sale', 'active', '1234567890', 'test@example.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'India', '1', NULL, NULL, NULL, NULL, NULL, 'India', NULL, NULL, NULL, NULL, NULL, 'full_time', NULL, NULL, NULL, 'sunday', '0', '0', NULL, NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'savings', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-02-25 11:46:53', '2026-02-25 11:46:53', '1');

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;
